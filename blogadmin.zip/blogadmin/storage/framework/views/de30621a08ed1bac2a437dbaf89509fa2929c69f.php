
<!-- <?php echo e(session('email')); ?>

<?php echo e(session('password')); ?> -->

<?php $__env->startSection('pageTitle', 'All Likes'); ?>
<?php $__env->startSection('main-container'); ?>


<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">
                    <div class="card-box mb-30">
                    <?php if(session('status')): ?>
                  <div class="card-alert card gradient-45deg-green-teal">
                    <div class="card-content white-text">
                      <p>
                        <i class="material-icons">check</i> SUCCESS : <?php echo e(session('status')); ?></p>
                    </div>
                  </div>
                    <?php endif; ?>
						<div class="pd-20">
							<h4 class="text-blue h4">Data Table Simple</h4>
							<p class="mb-0">
								you can find more options
								<a
									class="text-primary"
									href="https://datatables.net/"
									target="_blank"
									>Click Here</a
								>
							</p>
						</div>
						<div class="pb-20">
							<table class="data-table table stripe hover nowrap">
								<thead>
									<tr>
										<th class="table-plus datatable-nosort">Id</th>
										<th>Post Name</th>
										<th>Post Image</th>
										<th>Post Likes</th>
									</tr>
								</thead>
								<tbody>
                                    <?php 
                                    $i=0;
                                    foreach($alllikes as $d){ ?>
									<tr>
										<td class="table-plus"><?=$i; ?></td>
										<td><?=$d->post_name; ?></td>
										<td><img src="<?=url('uploads/apifileregistration/'.$d->post_image); ?>" style="width: 80px;" ></td>
										
                                        <td><?=$total[$i];
                                        ?></td>
										
									</tr>
									<?php
                                    $i++;
                                } ?>
								</tbody>
							</table>
						</div>
					</div>
                </div>
            </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogadmin\resources\views/admin/alllikes.blade.php ENDPATH**/ ?>